# Autogen - Teams

**Pages:** 1

---

## autogen_ext.teams — AutoGen

**URL:** https://microsoft.github.io/autogen/stable/reference/python/autogen_ext.teams.html

**Contents:**
- autogen_ext.teams#

---
